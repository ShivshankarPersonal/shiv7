(function () {
    'use strict';
    angular.module("videoContainerPanel", [])
        .directive("videoContainerPanel", function () {
            return {
                restrict: 'E',
                templateUrl: "templates/videoContainerPanel.html",
                scope:{
                    title:"@",
                    video:"@"
                },
                link: function ($scope, element, attr) {
                    $scope.videoURLMP4 = "resources/videos/"+$scope.video + ".mp4";
                    $scope.videoURLOGG = "resources/videos/"+$scope.video + ".ogg";
                    $scope.minimizePanel = function () {
                        var minizeIconElement = angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus')));
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if (minizeIconElement.length) {
                            angular.element(document.getElementsByClassName('minimizedPanelsHolder')).append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus'))).removeClass('glyphicon-minus').addClass('glyphicon-modal-window');
                        } else {
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                        }
                    };
                    $scope.maximizePanel = function () {
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if(angular.element(element).parent().hasClass('maximizePanel')){
                            angular.element(element).parent().removeClass('maximizePanel');
                        }else{
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                            angular.element(element).parent().addClass('maximizePanel');
                        }
                    };
                }
            }
        });
})();



