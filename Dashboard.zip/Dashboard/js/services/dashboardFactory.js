(function () {
    angular.module('dashboard')
        .factory("dashboardFactory", function ($http, $q) {
            return {
                getUserDetails: function () {
                    var deferred = $q.defer();
                    $http.get('./data/data.json').success(function (data, status, headers, config) {
                        deferred.resolve(data, status, headers, config);
                    }).error(function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config)
                    });
                    return deferred.promise;
                }
            }
        });
})();